package br.pucpr.authserver

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class AuthserverApplicationTests {

	@Test
	fun contextLoads() {
	}

}
