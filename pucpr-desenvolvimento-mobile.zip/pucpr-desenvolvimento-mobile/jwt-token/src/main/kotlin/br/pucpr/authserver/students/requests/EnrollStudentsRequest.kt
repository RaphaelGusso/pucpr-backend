package br.pucpr.authserver.students.requests

import jakarta.validation.constraints.NotBlank
import jakarta.validation.constraints.NotNull

data class EnrollStudentsRequest (
    @NotNull
    val courseId: Long,

    @NotNull
    val studentId: Long,
)