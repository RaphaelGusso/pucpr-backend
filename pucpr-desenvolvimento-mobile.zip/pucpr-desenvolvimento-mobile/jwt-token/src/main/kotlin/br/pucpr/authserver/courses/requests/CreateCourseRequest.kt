package br.pucpr.authserver.courses.requests

import jakarta.validation.constraints.NotBlank

data class CreateCourseRequest(
    @NotBlank
    val name: String,

    @NotBlank
    val code: String,

    @NotBlank
    val description: String
)