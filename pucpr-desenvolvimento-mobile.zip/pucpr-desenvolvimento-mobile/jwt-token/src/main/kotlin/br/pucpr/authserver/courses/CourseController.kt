package br.pucpr.authserver.courses

import br.pucpr.authserver.courses.requests.CreateCourseRequest
import br.pucpr.authserver.courses.requests.UpdateCourseRequest
import br.pucpr.authserver.courses.responses.CourseResponse
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.security.SecurityRequirement
import jakarta.validation.Valid
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.security.access.prepost.PreAuthorize
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/courses")
class CourseController(val courseService: CourseService) {

    @SecurityRequirement(name = "jwt-auth")
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    @ApiResponse(responseCode = "201")
    fun insert(
        @RequestBody @Valid request: CreateCourseRequest
    ) = courseService.insert(request.name, request.code, request.description)
        .let { CourseResponse(it) }
        .let { ResponseEntity.status(HttpStatus.CREATED).body(it) }

    @GetMapping
    fun list(): ResponseEntity<List<CourseResponse>> =
        courseService.findAll()
            .map { CourseResponse(it) }
            .let { ResponseEntity.ok(it) }

    @GetMapping("/{id}")
    fun getById(@PathVariable id: Long): ResponseEntity<CourseResponse> =
        courseService.findById(id)
            .let { CourseResponse(it) }
            .let { ResponseEntity.ok(it) }

    @GetMapping("/student/{studentId}")
    fun listByStudent(@PathVariable studentId: Long): ResponseEntity<List<CourseResponse>> =
        courseService.findByStudentId(studentId)
            .map { CourseResponse(it) }
            .let { ResponseEntity.ok(it) }

    @SecurityRequirement(name = "jwt-auth")
    @PreAuthorize("hasRole('ADMIN')")
    @PatchMapping("/{id}")
    fun update(
        @PathVariable id: Long,
        @RequestBody @Valid request: UpdateCourseRequest
    ) = courseService.update(id, request.name, request.description)
        ?.let { CourseResponse(it) }
        ?.let { ResponseEntity.ok(it) }
        ?: ResponseEntity.noContent().build()

    @SecurityRequirement(name = "jwt-auth")
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    fun delete(@PathVariable id: Long): ResponseEntity<Void> {
        courseService.delete(id)
        return ResponseEntity.noContent().build()
    }
}
