package br.pucpr.authserver.courses.requests

data class UpdateCourseRequest(
    val name: String?,
    val description: String?
)
