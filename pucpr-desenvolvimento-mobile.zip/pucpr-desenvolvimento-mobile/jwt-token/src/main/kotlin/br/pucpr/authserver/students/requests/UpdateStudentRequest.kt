package br.pucpr.authserver.students.requests

import jakarta.validation.constraints.Email
import jakarta.validation.constraints.Min

data class UpdateStudentRequest(
    val name: String?,

    @Email
    val email: String?,

    val document: String?,

    @Min(1)
    val age: Int?
)
