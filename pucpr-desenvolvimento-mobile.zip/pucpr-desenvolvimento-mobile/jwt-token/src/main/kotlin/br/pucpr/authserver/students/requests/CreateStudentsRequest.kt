package br.pucpr.authserver.students.requests

import br.pucpr.authserver.students.Students
import jakarta.validation.constraints.Email
import jakarta.validation.constraints.Min
import jakarta.validation.constraints.NotBlank

data class CreateStudentsRequest(
    @NotBlank
    val name: String,

    @NotBlank
    @Email
    val email: String,

    @NotBlank
    val document: String,

    @Min(1)
    val age: Int
) {
    fun toStudent() = Students(
        name = name,
        email = email,
        document = document,
        age = age
    )
}
