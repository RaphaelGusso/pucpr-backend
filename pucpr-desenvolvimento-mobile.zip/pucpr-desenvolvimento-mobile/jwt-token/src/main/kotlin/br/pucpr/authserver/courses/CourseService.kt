package br.pucpr.authserver.courses

import br.pucpr.authserver.exceptions.BadRequestException
import br.pucpr.authserver.exceptions.NotFoundException
import br.pucpr.authserver.students.Students
import br.pucpr.authserver.students.StudentsService
import org.slf4j.LoggerFactory
import org.springframework.data.repository.findByIdOrNull
import org.springframework.stereotype.Service

@Service
class CourseService(
    val repository: CourseRepository,
    val studentsService: StudentsService
) {
    fun insert(name: String, code: String, description: String): Course {
        if (repository.findByCode(code) != null) {
            throw BadRequestException("Course with code $code already exists")
        }
        val course = Course(name = name, code = code, description = description)
        return repository.save(course)
            .also { log.info("Course {} added.", it.id) }
    }

    fun findAll(): List<Course> = repository.findAll()

    fun findByStudentId(studentId: Long): List<Course> {
        studentsService.findById(studentId) //
        return repository.findByStudentId(studentId)
    }

    fun findByIdOrNull(id: Long): Course? = repository.findByIdOrNull(id)

    fun findById(id: Long): Course =
        findByIdOrNull(id) ?: throw NotFoundException(id)

    fun update(id: Long, name: String?, description: String?): Course? {
        val course = findById(id)
        var changed = false

        name?.let { if (it != course.name) { course.name = it; changed = true } }
        description?.let { if (it != course.description) { course.description = it; changed = true } }

        if (!changed) return null
        repository.save(course)
        log.info("Course {} updated.", course.id)
        return course
    }

    fun delete(id: Long) {
        val course = findById(id)
        repository.delete(course)
        log.warn("Course {} deleted.", id)
    }

    fun enroll(studentId: Long, courseId: Long): Students {
        val student = studentsService.findById(studentId)
        val course = findById(courseId)

        if (student.courses.any { it.id == courseId }) {
            throw BadRequestException("Student $studentId is already enrolled in course $courseId")
        }

        student.courses.add(course)
        studentsService.repository.save(student)
        log.info("Student {} enrolled in course {}.", studentId, courseId)
        return student
    }

    companion object {
        val log = LoggerFactory.getLogger(CourseService::class.java)
    }
}
