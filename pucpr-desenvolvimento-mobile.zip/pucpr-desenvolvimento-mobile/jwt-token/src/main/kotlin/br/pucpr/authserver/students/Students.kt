package br.pucpr.authserver.students

import br.pucpr.authserver.courses.Course
import jakarta.persistence.*

@Entity
@Table(name = "StudentsTable")
class Students(
    @Id
    @GeneratedValue
    var id: Long? = null,

    @Column(nullable = false)
    var name: String,

    @Column(nullable = false, unique = true)
    var email: String,

    var document: String,

    var age: Int,

    @ManyToMany
    @JoinTable(
        name = "StudentCourse",
        joinColumns = [JoinColumn(name = "student_id")],
        inverseJoinColumns = [JoinColumn(name = "course_id")]
    )
    var courses: MutableSet<Course> = mutableSetOf()
)
