package br.pucpr.authserver.students

import br.pucpr.authserver.exceptions.BadRequestException
import br.pucpr.authserver.exceptions.NotFoundException
import org.slf4j.LoggerFactory
import org.springframework.data.repository.findByIdOrNull
import org.springframework.stereotype.Service
import jakarta.persistence.criteria.Predicate
import org.springframework.data.domain.Sort
import org.springframework.data.jpa.domain.Specification

@Service
class StudentsService(
    val repository: StudentsRepository
) {
    fun insert(student: Students): Students {
        if (repository.findByEmail(student.email) != null) {
            throw BadRequestException("Student with email ${student.email} already exists")
        }
        return repository.save(student)
            .also { log.info("Student {} added.", it.id) }
    }

    fun findAll(name: String?, sortDir: String?): List<Students> {
        val spec = Specification<Students> { root, _, cb ->
            val predicates = mutableListOf<Predicate>()

            name?.let {
                predicates.add(cb.like(cb.lower(root.get("name")), "%${it.lowercase()}%"))
            }

            cb.and(*predicates.toTypedArray())
        }

        val sort = if (sortDir?.uppercase() == "DESC")
            Sort.by("name").descending()
        else
            Sort.by("name").ascending()

        return repository.findAll(spec, sort)
    }

    fun findByIdOrNull(id: Long): Students? = repository.findByIdOrNull(id)

    fun findById(id: Long): Students =
        findByIdOrNull(id) ?: throw NotFoundException(id)

    fun update(id: Long, name: String?, email: String?, document: String?, age: Int?): Students? {
        val student = findById(id)
        var changed = false

        name?.let { if (it != student.name) { student.name = it; changed = true } }
        email?.let {
            if (it != student.email) {
                if (repository.findByEmail(it) != null) throw BadRequestException("Email already in use")
                student.email = it
                changed = true
            }
        }
        document?.let { if (it != student.document) { student.document = it; changed = true } }
        age?.let { if (it != student.age) { student.age = it; changed = true } }

        if (!changed) return null
        repository.save(student)
        log.info("Student {} updated.", student.id)
        return student
    }

    fun delete(id: Long) {
        val student = findById(id)
        repository.delete(student)
        log.warn("Student {} deleted.", id)
    }

    companion object {
        val log = LoggerFactory.getLogger(StudentsService::class.java)
    }
}
