package br.pucpr.authserver.courses.responses

import br.pucpr.authserver.courses.Course

data class CourseResponse(
    val id: Long,
    val name: String,
    val code: String,
    val description: String,
    val students: List<String>
) {
    constructor(course: Course) : this(
        id = course.id!!,
        name = course.name,
        code = course.code,
        description = course.description,
        students = course.students.map { it.name }
    )
}