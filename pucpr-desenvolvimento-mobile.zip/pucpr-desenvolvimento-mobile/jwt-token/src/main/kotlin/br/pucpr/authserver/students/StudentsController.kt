package br.pucpr.authserver.students

import br.pucpr.authserver.courses.CourseService
import br.pucpr.authserver.courses.responses.CourseResponse
import br.pucpr.authserver.students.requests.CreateStudentsRequest
import br.pucpr.authserver.students.requests.EnrollStudentsRequest
import br.pucpr.authserver.students.requests.UpdateStudentRequest
import br.pucpr.authserver.students.responses.StudentResponse
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.security.SecurityRequirement
import jakarta.validation.Valid
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.security.access.prepost.PreAuthorize
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/students")
class StudentsController(val studentsService: StudentsService, private val courseService: CourseService) {

    @SecurityRequirement(name = "jwt-auth")
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    @ApiResponse(responseCode = "201")
    fun insert(
        @RequestBody @Valid student: CreateStudentsRequest
    ) = studentsService.insert(student.toStudent())
        .let { StudentResponse(it) }
        .let { ResponseEntity.status(HttpStatus.CREATED).body(it) }

    @GetMapping
    fun list(
        @RequestParam(required = false) name: String?,
        @RequestParam(required = false, defaultValue = "ASC") sortDir: String
    ): ResponseEntity<List<StudentResponse>> =
        studentsService.findAll(name, sortDir)
            .map { StudentResponse(it) }
            .let { ResponseEntity.ok(it) }

    @GetMapping("/{id}")
    fun getById(@PathVariable id: Long): ResponseEntity<StudentResponse> =
        studentsService.findById(id)
            .let { StudentResponse(it) }
            .let { ResponseEntity.ok(it) }

    @SecurityRequirement(name = "jwt-auth")
    @PreAuthorize("hasRole('ADMIN')")
    @PatchMapping("/{id}")
    fun update(
        @PathVariable id: Long,
        @RequestBody @Valid request: UpdateStudentRequest
    ) = studentsService.update(id, request.name, request.email, request.document, request.age)
        ?.let { StudentResponse(it) }
        ?.let { ResponseEntity.ok(it) }
        ?: ResponseEntity.noContent().build()

    @SecurityRequirement(name = "jwt-auth")
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    fun delete(@PathVariable id: Long): ResponseEntity<Void> {
        studentsService.delete(id)
        return ResponseEntity.noContent().build()
    }

    @SecurityRequirement(name = "jwt-auth")
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/enroll")
    @ApiResponse(responseCode = "200")
    fun enroll(
        @RequestBody @Valid student: EnrollStudentsRequest
    ): ResponseEntity<CourseResponse> =
        courseService.enroll(student.studentId, student.courseId)
            .let { courseService.findById(student.courseId) }
            .let { CourseResponse(it) }
            .let { ResponseEntity.ok(it) }
}
