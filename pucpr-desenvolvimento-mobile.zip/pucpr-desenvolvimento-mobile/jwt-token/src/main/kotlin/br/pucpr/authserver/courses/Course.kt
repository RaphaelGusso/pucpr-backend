package br.pucpr.authserver.courses

import br.pucpr.authserver.students.Students
import jakarta.persistence.*

@Entity
@Table(name = "CourseTable")
class Course(
    @Id
    @GeneratedValue
    var id: Long? = null,

    @Column(nullable = false)
    var name: String,

    @Column(nullable = false, unique = true)
    var code: String,

    @Column(nullable = false)
    var description: String,

    @ManyToMany(mappedBy = "courses")
    var students: MutableSet<Students> = mutableSetOf()
)