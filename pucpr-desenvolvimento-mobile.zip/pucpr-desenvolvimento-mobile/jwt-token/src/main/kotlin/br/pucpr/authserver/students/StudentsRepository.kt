package br.pucpr.authserver.students

import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.JpaSpecificationExecutor

interface StudentsRepository : JpaRepository<Students, Long>,
    JpaSpecificationExecutor<Students> {
    fun findByEmail(email: String): Students?
}
