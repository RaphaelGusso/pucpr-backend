package br.pucpr.authserver.students.responses

import br.pucpr.authserver.students.Students

data class StudentResponse(
    val id: Long,
    val name: String,
    val email: String,
    val document: String,
    val age: Int
) {
    constructor(student: Students) : this(
        id = student.id!!,
        name = student.name,
        email = student.email,
        document = student.document,
        age = student.age
    )
}
