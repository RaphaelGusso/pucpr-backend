package br.pucpr.authserver.courses

import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query

interface CourseRepository : JpaRepository<Course, Long> {
    fun findByCode(code: String): Course?

    @Query("SELECT c FROM Course c JOIN c.students s WHERE s.id = :studentId")
    fun findByStudentId(studentId: Long): List<Course>
}